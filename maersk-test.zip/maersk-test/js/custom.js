$(document).ready(function(){
    console.log('hello')

//shuffle
$('.shuffle-click').on('click',()=> {
    shuffleElements( $('.card') );
})

function shuffleElements($elements) {
	let i, index1, index2, tempval;
	const count = $elements.length;
	const $parent = $elements.parent();
	const shuffle_arr = [];
	
	for (i = 0; i < count; i++) {
		shuffle_arr.push(i);
	}
	
	for (i = 0; i < count; i++) {
		index1 = (Math.random() * count) | 0;
		index2 = (Math.random() * count) | 0;
		tempval = shuffle_arr[index1];
		shuffle_arr[index1] = shuffle_arr[index2];
		shuffle_arr[index2] = tempval;
	}

	for (i = 0; i < count; i++) {
		$parent.append( $elements.eq(shuffle_arr[i]) );
	}
}

// Sorting

$('.sort-click').on('click',()=> {
    sortFun();
})
function sortFun() 
{
    let wrapperSec = $('.cards-section');
    wrapperSec.find('.card').sort(function(a, b) 
    {
        return + a.getAttribute('data-sort') - 
        +b.getAttribute('data-sort');
    })
    .appendTo(wrapperSec);
}
})